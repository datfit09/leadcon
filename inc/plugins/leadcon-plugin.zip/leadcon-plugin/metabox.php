<?php
/*
 SETTING PAGE(META BOX)
 */

function leadcon_pagesetting_meta_box() {
	add_meta_box( 'page_setting', 'Page Settings', 'leadcon_pagesetting_output', 'page', 'side');
}

add_action( 'add_meta_boxes', 'leadcon_pagesetting_meta_box' );

function leadcon_pagesetting_output($page) {
	$footer = get_post_meta( $page->ID, 'show_footer', true );
	$page_header = get_post_meta( $page->ID, 'page_header', true );
	$container = get_post_meta( $page->ID, 'container', true );
	$transparent = get_post_meta( $page->ID, 'transparent', true );
	$checked = '';
	$header = '';

	if ( $footer === 'hidden' ) {
		$checked = 'checked';
	}

	if ( $page_header === 'hidden' ) {
		$header = 'checked';
	}

	$option_container = array(
		'default'    => 'Use Customize Setting',
		'container'  => 'Container',
		'full-width' => 'Full Width',
		'box'        => 'Box',
	);


	$option_transparent = array(
		'default'    => 'Use Customize Setting',
		'show'  => 'Enable',
		'hidden' => 'Disable',

	);

	wp_nonce_field( 'gwp_pc_nonce_action', 'gwp_pc_nonce' );
	?>

	<div class="form-meta-footer">

		<div class="input-wrapper">

			<label class="footer-switch">
				<?php echo esc_html__('Hidden Footer', 'leadcon'); ?>
				<input type="checkbox" name="show_footer" value="hidden" <?php echo esc_attr( $checked ); ?>>
				<span class="checkmark"></span>
			</label>
			<label class="footer-switch">
				<?php echo esc_html__('Hidden Page Header', 'leadcon'); ?>
				<input type="checkbox" name="page_header" value="hidden"<?php echo esc_attr( $header );?>>
				<span class="checkmark"></span>
			</label>
		</div>


		<div class="input-wrapper">
			<label for="container">Site Container</label>
			<select name="container" id="container">
				<?php foreach ($option_container as $value => $option): ?>
					<?php $selected = ( $container === $value ) ? 'selected' : '' ?>
					<option value="<?php echo esc_attr($value); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($option); ?></option>
				<?php endforeach ?>
			</select>
		</div>


		<div class="input-wrapper">
			<label for="header-transparent">Header Transparent</label>
			<select name="transparent" id="header-transparent">
				<?php foreach ($option_transparent as $value => $option): ?>
					<?php $selected = ( $transparent === $value ) ? 'selected' : '' ?>
					<option value="<?php echo esc_attr($value); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($option); ?></option>
				<?php endforeach ?>
			</select>
		</div>

	</div>
	<?php
}

function leadcon_pagesetting_save( $post_id )
{

	$nonce_name   = isset( $_POST['gwp_pc_nonce'] ) ? $_POST['gwp_pc_nonce'] : '';
	$nonce_action = 'gwp_pc_nonce_action';

	if ( ! isset( $nonce_name ) )
		return;
	// Check if a nonce is valid.
	if ( ! wp_verify_nonce( $nonce_name, $nonce_action ) )
		return;

	// Check if the user has permissions to save data.
	if ( ! current_user_can( 'edit_post', $post_id ) )
		return;

	// Check if it's not an autosave.
	if ( wp_is_post_autosave( $post_id ) )
		return;

	// Check if it's not a revision.
	if ( wp_is_post_revision( $post_id ) )
		return;

		$footer = ( isset($_POST['show_footer']) ) ? sanitize_text_field( $_POST['show_footer'] ) : 'show';

		update_post_meta(
			$post_id,
			'show_footer',
			$footer
		);

		$pageHeader = ( isset($_POST['page_header']) ) ? sanitize_text_field( $_POST['page_header'] ) : 'show';
		update_post_meta(
			$post_id,
			'page_header',
			$pageHeader
		);

		$container = ( isset($_POST['container']) ) ? sanitize_text_field( $_POST['container'] ) : '';

		update_post_meta(
			$post_id,
			'container',
			$container
		);

		$transparent = ( isset($_POST['transparent']) ) ? sanitize_text_field( $_POST['transparent'] ) : '';

		update_post_meta(
			$post_id,
			'transparent',
			$transparent
		);

}
add_action( 'save_post', 'leadcon_pagesetting_save' );
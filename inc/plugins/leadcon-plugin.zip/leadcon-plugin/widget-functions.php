<?php
/*
Plugin Name: Leadcon Plugin
Plugin URI: https://google.com
Description: Leadcon Plugin.
Author: Boostify
Version: 1.0
Author URI: http://haintheme.com
*/
/*include plugin_dir_path( __FILE__ ) . 'metabox.php';*/
include plugin_dir_path( __FILE__ ) . 'widgets/class-leadcon-widget-recent-posts.php';
include plugin_dir_path( __FILE__ ) . 'widgets/class-leadcon-widget-product-fillter.php';

/**
 * Register Widgets.
 */
function leadcon_register_widgets() {
	register_widget( 'Leadcon_Widget_Recent_Posts' );

	if ( class_exists( 'WooCommerce' ) && class_exists( 'TA_WC_Variation_Swatches' ) ) {
		register_widget( 'Leadcon_Widget_Products_Filter' );
	}
}
add_action( 'widgets_init', 'leadcon_register_widgets' );
